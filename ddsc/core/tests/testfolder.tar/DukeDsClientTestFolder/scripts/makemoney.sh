make money
make install
